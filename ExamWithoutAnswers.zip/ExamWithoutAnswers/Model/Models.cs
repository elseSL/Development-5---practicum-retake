using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;


namespace reactTest.Model
{
  public class SchoolStudentsContext : DbContext
  {
    // TODO 1 (0.5 point): complete the implementation of the class
    ...

    public SchoolStudentsContext(DbContextOptions<SchoolStudentsContext> options)
        : base(options)
    { }

    protected override void OnModelCreating (ModelBuilder modelBuilder) {
         
          // TODO 2 (0.5 point): complete the implementation of the function 
            ...
        }
  }
  

  public class School
  {
    public int Id { get; set; }
    public string Name { get; set; }

    // TODO 3 (0.5 point): complete the implementation of the class
    ...
  }


  public class Student
  {
    public int Id { get; set; }
    public int Code { get; set; }
    public string Name { get; set; }
    
    // TODO 4 (0.5 point): complete the implementation of the class
    ...

  }
}