using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using reactTest.Model;

namespace reactTest.Controllers
{
    [Route("[controller]")]
    public class SchoolStudentsController : Controller
    {
        private readonly SchoolStudentsContext _context;

        public SchoolStudentsController(SchoolStudentsContext context)
        {
            _context = context;
            
            if(context.Students.Count() == 0 && context.Schools.Count() == 0){
            Console.WriteLine(4);
                

                var student1 = new Student(){ Id = 1, Name = "Tom", Code = 8391 };
                var student2 = new Student(){ Id = 2, Name = "Brad", Code = 9876 };
                var student3 = new Student(){ Id = 3, Name = "Arjo", Code = 3456 };
                var student4 = new Student(){ Id = 4, Name = "Tim", Code = 4756 };

                var school1 = new School() {
                    Id = 1,
                    Name = "Hogeschool Rotterdam",
                    Students = new List<Student>(){ student1, student2 }
                };
                var school2 = new School() {
                    Id = 2,
                    Name = "VU Amsterdam",
                    Students = new List<Student>(){ student3, student4 }
                };
                _context.Students.Add(student1);
                _context.Students.Add(student2);
                _context.Students.Add(student3);
                _context.Students.Add(student4);

                _context.Schools.Add(school1);
                _context.Schools.Add(school2);
                _context.SaveChanges();
            Console.WriteLine(5);

            }

        }
        
        [HttpGet("GetAll")]
        public IActionResult GetAll(){
            Console.WriteLine(1);
            _context.SaveChanges();

          // TODO 5 (2 points): complete the implementation of the query   
          var school_students = (from s in ...
                             let ... = (from c in ...
                                          where ...
                                          select new { ... })
                             select new {...}).ToList();
          return Ok(school_students);
        }


        [HttpGet("UpdateSchoolName/{school_id}/{school_name}")]
        public IActionResult UpdateSchoolName(int school_id, string school_name){
          
          // TODO 6 (1 point): complete the implementation of the function
          var school = ...
         
          if(...){
            return NotFound();
          }

          ...

          return Ok(school);
        }
    }
}