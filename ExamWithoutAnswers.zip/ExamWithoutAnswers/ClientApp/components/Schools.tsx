import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import * as Models from '../models'


async function getAll() : Promise<Models.School[]>{
    let responce = await fetch(`SchoolStudents/GetAll`, { method: 'get',  credentials: 'include', headers: { 'content-type': 'application/json' } })
    let res = responce.json()
    return res
  }

async function updateSchoolName(school:Models.School, new_name:string) : Promise<Models.School>{
    console.log("saving school")
    
    // TODO 7 (0.5 point): complete the implementation 
    let address = ...
    let responce = await fetch(address, { method: 'get',  credentials: 'include', headers: { 'content-type': 'application/json' } })
    
    let res = responce.json()
    console.log("res...", res)
    return res
}

// TODO 8 (1 point): complete the implementation 
type SchoolsComponentState = {...}

export class SchoolsComponent extends React.Component<RouteComponentProps<{}>, SchoolsComponentState> {
    constructor(props: RouteComponentProps<{}>, context: any) {
        super(props, context);
        this.state = {schools_and_students : "loading"};
    }
    componentWillMount(){
        // TODO 9 (1 point): complete the implementation of then() and catch() statements
        getAll().then(...)
                .catch(...)
    }
    public render() {
        if(this.state.schools_and_students == "loading") return <div>"loading"</div>
        if(this.state.schools_and_students == "error") return <div>"error"</div>
        return <div>
            {this.state.schools_and_students.map(b_a => <div>
                    <SchoolComponent school={b_a} save_school={(school, new_name) => updateSchoolName(school, new_name)
                                                                                    .then(b =>  this.state.schools_and_students != "loading" && 
                                                                                                this.state.schools_and_students != "error" &&
                                                                                                this.setState({...this.state, schools_and_students:this.state.schools_and_students.map(b1 => b1.id == b.id ? {...b1, name:b.name} : b1)}))
                                                                                                }/>
                </div>)}
            </div>

            
    }
}


type SchoolComponentProps = {school:Models.School, save_school:(school:Models.School, new_name:string)=>void}
export class SchoolComponent extends React.Component<SchoolComponentProps, {edit:boolean, school_name:string}> {
    constructor(props:SchoolComponentProps) {
        super(props);
        this.state = {edit:false, school_name:props.school.name}
    }

    

    public render() {
        return <div>
                
                School name: {!this.state.edit? this.props.school.name :
                             <input value={this.state.school_name} onChange={e=>this.setState({...this.state, school_name:e.target.value})}/>}

                {this.props.school.students.map(a => <StudentComponent student={a}/>)}

                {!this.state.edit?
                <button onClick={() => this.setState({...this.state, edit:true})}>Edit school names</button> :
                <button onClick={() => 
                            {
                                this.setState({...this.state, edit:false}, () => this.props.save_school(this.props.school, this.state.school_name))
                            }
                        }>Save changes</button>
            }
            </div>
    }
}

// TODO 10 (0.5 point) : complete the implementation of the missing type
type AutoComponentProps = ...

// TODO 11 (2 points): complete the implementation of student component
export class StudentComponent extends React.Component<AutoComponentProps, {}> {
   ...
}





