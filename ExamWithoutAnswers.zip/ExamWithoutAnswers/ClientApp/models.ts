export type School = {
  id:number,
  name:string,
  students:Student[]
}

export type Student = {
  id:number,
  name:string,
  code:string,
}
